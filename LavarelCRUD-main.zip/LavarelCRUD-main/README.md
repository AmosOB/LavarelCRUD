# LavarelCRUD
The project is the illustration of Create, Read, Update and Delete principle in PHP framework Laravel, I used HTML, CSS, JAVASCRIPT, BOOTSTRAP and PHP 
